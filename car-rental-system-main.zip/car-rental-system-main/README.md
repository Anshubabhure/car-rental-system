# car-rental-system
For the project assignment of the Object Oriented Programming (CENG201) course, coding a Car Rental Management System using Java
